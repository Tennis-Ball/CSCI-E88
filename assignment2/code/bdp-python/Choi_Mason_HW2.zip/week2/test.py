import pandas as pd

df = pd.read_csv("file-input1.csv")
counter = 0
for 